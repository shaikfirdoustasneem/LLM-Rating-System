"""
Data loading and validation for LLM Ranking System.
Uses Pydantic for schema validation.
"""

import logging
from pathlib import Path
from typing import List, Dict, Optional, Tuple
import pandas as pd
import numpy as np
from pydantic import BaseModel, Field, validator

logger = logging.getLogger(__name__)


# Pydantic Models for validation
class PromptData(BaseModel):
    """Schema for a prompt with answers and model names."""
    prompt: str = Field(..., min_length=1, max_length=5000, description="The input prompt")
    answers: List[str] = Field(..., min_items=2, max_items=10, description="Answers from different models")
    model_names: List[str] = Field(..., min_items=2, max_items=10, description="Names of models that provided answers")
    
    @validator('answers')
    def answers_must_be_strings(cls, v):
        return [str(a).strip() for a in v]
    
    @validator('model_names')
    def model_names_must_be_strings(cls, v):
        return [str(m).strip() for m in v]
    
    @validator('answers', 'model_names', pre=True)
    def check_lengths_match(cls, v, values):
        if 'answers' in values and 'model_names' in values:
            if len(values['answers']) != len(v):
                raise ValueError("Number of answers must match number of model names")
        return v


class DatasetRow(BaseModel):
    """Schema for a single dataset row."""
    prompt: str = Field(..., description="Input prompt")
    category: str = Field(..., description="Answer category/domain")
    model_name: str = Field(..., description="LLM model name")
    answer_text: str = Field(..., description="LLM's answer")
    human_score: Optional[float] = Field(None, ge=0.0, le=10.0, description="Human rating 0-10")
    prompt_id: Optional[str] = Field(None, description="Prompt identifier")


class DataLoader:
    """Handle data loading and validation."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    @staticmethod
    def load_csv(csv_path: Path, limit: Optional[int] = None) -> pd.DataFrame:
        """
        Load CSV dataset.
        
        Args:
            csv_path: Path to CSV file
            limit: Maximum rows to load (for testing)
        
        Returns:
            DataFrame with validated data
        """
        logger.info(f"Loading CSV from {csv_path}")
        
        try:
            df = pd.read_csv(csv_path, nrows=limit)
            logger.info(f"Loaded {len(df)} rows")
            
            # Validate required columns
            required_cols = {'prompt', 'category', 'model_name', 'answer_text', 'human_score'}
            missing_cols = required_cols - set(df.columns)
            
            if missing_cols:
                raise ValueError(f"Missing columns: {missing_cols}")
            
            # Data quality checks
            logger.info("Running data quality checks...")
            
            # Check for nulls
            nulls = df[list(required_cols)].isnull().sum()
            if nulls.any():
                logger.warning(f"Found null values:\n{nulls[nulls > 0]}")
                df = df.dropna(subset=list(required_cols))
            
            # Check score range
            score_issues = df[
                (df['human_score'] < 0) | (df['human_score'] > 10)
            ]
            if len(score_issues) > 0:
                logger.warning(f"Found {len(score_issues)} scores outside 0-10 range, filtering")
                df = df[(df['human_score'] >= 0) & (df['human_score'] <= 10)]
            
            logger.info(f"After validation: {len(df)} rows retained")
            return df
            
        except Exception as e:
            logger.error(f"Failed to load CSV: {e}")
            raise
    
    @staticmethod
    def load_parquet(parquet_path: Path) -> pd.DataFrame:
        """Load Parquet dataset."""
        logger.info(f"Loading Parquet from {parquet_path}")
        try:
            df = pd.read_parquet(parquet_path)
            logger.info(f"Loaded {len(df)} rows")
            return df
        except Exception as e:
            logger.error(f"Failed to load Parquet: {e}")
            raise
    
    @staticmethod
    def save_parquet(df: pd.DataFrame, output_path: Path) -> None:
        """Save DataFrame as Parquet."""
        logger.info(f"Saving {len(df)} rows to {output_path}")
        output_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            df.to_parquet(output_path, index=False)
            logger.info(f"Saved to {output_path}")
        except Exception as e:
            logger.error(f"Failed to save Parquet: {e}")
            raise
    
    @staticmethod
    def create_train_test_split(
        df: pd.DataFrame,
        test_size: float = 0.2,
        random_state: int = 42,
        stratify_by: Optional[str] = None
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Create train/test split.
        
        Args:
            df: Input dataframe
            test_size: Fraction for test set
            random_state: Random seed
            stratify_by: Column to stratify by (e.g., 'category')
        
        Returns:
            (train_df, test_df)
        """
        from sklearn.model_selection import train_test_split
        
        logger.info(f"Creating train/test split ({1-test_size:.0%}/{test_size:.0%})")
        
        stratify = df[stratify_by] if stratify_by and stratify_by in df.columns else None
        
        train_df, test_df = train_test_split(
            df,
            test_size=test_size,
            random_state=random_state,
            stratify=stratify
        )
        
        logger.info(f"Train: {len(train_df)} rows, Test: {len(test_df)} rows")
        return train_df, test_df
    
    @staticmethod
    def get_dataset_statistics(df: pd.DataFrame) -> Dict:
        """Get dataset statistics."""
        stats = {
            'total_rows': len(df),
            'unique_prompts': df['prompt_id'].nunique() if 'prompt_id' in df.columns else df['prompt'].nunique(),
            'unique_models': df['model_name'].nunique(),
            'unique_categories': df['category'].nunique() if 'category' in df.columns else 0,
            'score_mean': float(df['human_score'].mean()),
            'score_std': float(df['human_score'].std()),
            'score_min': float(df['human_score'].min()),
            'score_max': float(df['human_score'].max()),
        }
        
        if 'category' in df.columns:
            stats['category_distribution'] = df['category'].value_counts().to_dict()
        
        if 'model_name' in df.columns:
            stats['model_distribution'] = df['model_name'].value_counts().to_dict()
        
        return stats
    
    @staticmethod
    def validate_prompt_input(prompt_data: PromptData) -> None:
        """
        Validate user input prompt.
        
        Args:
            prompt_data: Validated prompt input
        
        Raises:
            ValueError: If validation fails
        """
        if len(prompt_data.answers) != len(prompt_data.model_names):
            raise ValueError("Number of answers must equal number of model names")
        
        if len(prompt_data.prompt.strip()) == 0:
            raise ValueError("Prompt cannot be empty")
        
        if any(len(a.strip()) == 0 for a in prompt_data.answers):
            raise ValueError("No answer can be empty")
        
        logger.info(
            f"Validated input: prompt ({len(prompt_data.prompt)} chars), "
            f"{len(prompt_data.answers)} answers"
        )
