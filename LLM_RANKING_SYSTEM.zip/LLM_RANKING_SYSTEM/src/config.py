"""
Configuration management for LLM Ranking System.
Loads settings from config.yaml and environment variables.
"""

import os
import yaml
from pathlib import Path
from typing import Dict, Any, Optional
import logging

logger = logging.getLogger(__name__)


class Config:
    """Central configuration manager."""
    
    def __init__(self, config_path: Optional[str] = None):
        """
        Initialize configuration.
        
        Args:
            config_path: Path to config.yaml file. 
                        If None, looks for config.yaml in current directory or project root.
        """
        if config_path is None:
            # Try current directory, then parent directories
            for possible_path in [
                Path("config.yaml"),
                Path(__file__).parent.parent / "config.yaml",
            ]:
                if possible_path.exists():
                    config_path = str(possible_path)
                    break
        
        if config_path is None:
            raise FileNotFoundError(
                "config.yaml not found. Please create it in the project root."
            )
        
        self.config_path = Path(config_path)
        self._config: Dict[str, Any] = {}
        self.load()
    
    def load(self) -> None:
        """Load configuration from YAML file."""
        try:
            with open(self.config_path, 'r') as f:
                self._config = yaml.safe_load(f) or {}
            logger.info(f"Configuration loaded from {self.config_path}")
        except Exception as e:
            logger.error(f"Failed to load config: {e}")
            raise
    
    def get(self, key: str, default: Any = None) -> Any:
        """
        Get configuration value with environment variable override support.
        
        Args:
            key: Dot-separated key path (e.g., 'model.learning_rate')
            default: Default value if key not found
        
        Returns:
            Configuration value
        
        Example:
            >>> config.get('model.learning_rate', 0.05)
            0.05
        """
        # Check environment variable first (uppercase, underscores)
        env_key = f"RANKING_{key.upper().replace('.', '_')}"
        if env_key in os.environ:
            value = os.environ[env_key]
            # Try to convert to appropriate type
            if value.lower() in ('true', 'false'):
                return value.lower() == 'true'
            try:
                return float(value) if '.' in value else int(value)
            except ValueError:
                return value
        
        # Navigate nested dict
        keys = key.split('.')
        value = self._config
        
        for k in keys:
            if isinstance(value, dict):
                value = value.get(k)
                if value is None:
                    return default
            else:
                return default
        
        return value if value is not None else default
    
    def get_path(self, key: str) -> Path:
        """Get a path from configuration and expand it."""
        path_str = self.get(key)
        if path_str is None:
            raise ValueError(f"Path configuration '{key}' not found")
        
        path = Path(path_str).expanduser()
        
        # Create parent directories if they don't exist
        if key.startswith('paths.') and not any(x in key for x in ['dataset', 'model', 'predictor']):
            path.mkdir(parents=True, exist_ok=True)
        elif 'output' in key or 'log' in key:
            path.parent.mkdir(parents=True, exist_ok=True)
        
        return path
    
    def to_dict(self) -> Dict[str, Any]:
        """Return configuration as dictionary."""
        return self._config.copy()


# Global config instance
_config_instance: Optional[Config] = None


def get_config(config_path: Optional[str] = None) -> Config:
    """Get or create global config instance."""
    global _config_instance
    if _config_instance is None:
        _config_instance = Config(config_path)
    return _config_instance


def reload_config(config_path: Optional[str] = None) -> Config:
    """Reload configuration."""
    global _config_instance
    _config_instance = Config(config_path)
    return _config_instance
