"""
Inference pipeline for LLM Ranking System.
Handles model loading, prediction, and explanation generation.
"""

import logging
import joblib
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import pandas as pd
import numpy as np
from datetime import datetime

from .config import get_config
from .features import FeatureExtractor
from .data import DataLoader, PromptData

logger = logging.getLogger(__name__)


class RankingModel:
    """LightGBM ranking model wrapper."""
    
    def __init__(self, model_path: Path, feature_cols: Optional[List[str]] = None):
        """
        Load ranking model.
        
        Args:
            model_path: Path to saved model joblib file
            feature_cols: Feature column names. If None, tries to recover from meta file
        """
        self.model_path = Path(model_path)
        self.feature_cols = feature_cols
        self.model = None
        self.best_iteration = None
        
        logger.info(f"Loading model from {model_path}")
        self.load()
        
        # Try to recover feature columns
        if self.feature_cols is None:
            self.feature_cols = self._recover_feature_cols()
    
    def load(self) -> None:
        """Load model from disk."""
        if not self.model_path.exists():
            raise FileNotFoundError(f"Model file not found: {self.model_path}")
        
        try:
            self.model = joblib.load(self.model_path)
            logger.info("Model loaded successfully")
            
            # Get best iteration if available
            if hasattr(self.model, 'best_iteration'):
                self.best_iteration = self.model.best_iteration
                logger.info(f"Best iteration: {self.best_iteration}")
        except Exception as e:
            logger.error(f"Failed to load model: {e}")
            raise
    
    def _recover_feature_cols(self) -> List[str]:
        """Recover feature columns from model or meta file."""
        config = get_config()
        
        # Try meta file
        meta_path = config.get_path('paths.model_meta')
        if meta_path.exists():
            try:
                meta = joblib.load(meta_path)
                if isinstance(meta, dict) and 'feature_cols' in meta:
                    cols = list(meta['feature_cols'])
                    logger.info(f"Recovered {len(cols)} feature columns from meta file")
                    return cols
            except Exception as e:
                logger.warning(f"Failed to load meta file: {e}")
        
        # Try from model
        try:
            cols = list(self.model.feature_name())
            logger.info(f"Recovered {len(cols)} feature columns from model")
            return cols
        except Exception:
            pass
        
        # Try CSV fallback
        csv_path = config.get_path('paths.csv_legacy')
        if csv_path.exists():
            try:
                df = pd.read_csv(csv_path, nrows=1)
                drop_cols = {'prompt_id', 'prompt', 'answer_text', 'model_name', 'category', 'human_score'}
                cols = [c for c in df.columns if c not in drop_cols]
                logger.info(f"Recovered {len(cols)} feature columns from CSV")
                return cols
            except Exception as e:
                logger.warning(f"Failed to recover from CSV: {e}")
        
        raise RuntimeError(
            "Could not recover feature columns. Please provide them explicitly."
        )
    
    def predict(self, X: pd.DataFrame) -> np.ndarray:
        """
        Make predictions.
        
        Args:
            X: Feature matrix
        
        Returns:
            Prediction scores
        """
        if self.model is None:
            raise RuntimeError("Model not loaded")
        
        try:
            preds = self.model.predict(
                X,
                num_iteration=self.best_iteration
            )
            return preds
        except Exception as e:
            logger.error(f"Prediction failed: {e}")
            raise
    
    def predict_with_contrib(self, X: pd.DataFrame) -> Tuple[np.ndarray, pd.DataFrame]:
        """
        Make predictions and get feature contributions (SHAP-like).
        
        Args:
            X: Feature matrix
        
        Returns:
            (predictions, contribution_dataframe)
        """
        preds = self.predict(X)
        
        try:
            contribs = self.model.predict(
                X,
                pred_contrib=True,
                num_iteration=self.best_iteration
            )
            contrib_df = pd.DataFrame(
                contribs,
                columns=self.feature_cols + ['bias']
            )
            return preds, contrib_df
        except Exception as e:
            logger.warning(f"Could not get contributions: {e}")
            # Return dummy contributions
            contrib_df = pd.DataFrame(
                np.zeros((len(X), len(self.feature_cols) + 1)),
                columns=self.feature_cols + ['bias']
            )
            return preds, contrib_df


class CategoryPredictor:
    """Predict answer category from prompt."""
    
    def __init__(self, model_path: Optional[Path] = None):
        """
        Initialize category predictor.
        
        Args:
            model_path: Path to category predictor model
        """
        self.model = None
        
        if model_path is None:
            config = get_config()
            model_path = config.get_path('paths.category_predictor')
        
        if Path(model_path).exists():
            try:
                logger.info(f"Loading category predictor from {model_path}")
                self.model = joblib.load(model_path)
                logger.info("Category predictor loaded")
            except Exception as e:
                logger.warning(f"Failed to load category predictor: {e}")
    
    def predict(self, prompt: str, default: str = "MISC") -> str:
        """
        Predict category for a prompt.
        
        Args:
            prompt: Input prompt
            default: Default category if prediction fails
        
        Returns:
            Predicted category
        """
        if self.model is None:
            logger.debug(f"Category predictor not available, returning default: {default}")
            return default
        
        try:
            pred = self.model.predict([prompt])[0].upper()
            logger.debug(f"Predicted category: {pred}")
            return pred
        except Exception as e:
            logger.warning(f"Category prediction failed: {e}, returning {default}")
            return default


class RankingInference:
    """Complete inference pipeline."""
    
    def __init__(self, config_path: Optional[str] = None):
        """Initialize inference pipeline."""
        self.config = get_config() if config_path is None else get_config(config_path)
        
        # Load components
        logger.info("Initializing inference pipeline...")
        
        model_path = self.config.get_path('paths.model')
        self.ranking_model = RankingModel(model_path)
        
        embedding_model = self.config.get('inference.embedding_model')
        self.feature_extractor = FeatureExtractor(embedding_model)
        
        category_path = self.config.get_path('paths.category_predictor')
        self.category_predictor = CategoryPredictor(category_path)
        
        self.llm_links = {
            "Mistral": "https://mistral.ai/",
            "Grok": "https://grok.com/",
            "Perplexity": "https://www.perplexity.ai/",
            "Claude": "https://claude.ai/new",
            "Gemini": "https://gemini.google.com/app",
            "Qwen": "https://chat.qwen.ai/",
            "Chatgpt": "https://chatgpt.com/",
            "Deepseek": "https://chat.deepseek.com/",
            "mistral": "https://mistral.ai/",
            "grok": "https://grok.com/",
            "perplexity": "https://www.perplexity.ai/",
            "claude": "https://claude.ai/new",
            "gemini": "https://gemini.google.com/app",
            "qwen": "https://chat.qwen.ai/",
            "chatgpt": "https://chatgpt.com/",
            "deepseek": "https://chat.deepseek.com/",
        }
        
        logger.info("Inference pipeline initialized")
    
    def predict_and_rank(
        self,
        prompt: str,
        answers: List[str],
        model_names: List[str]
    ) -> Dict:
        """
        Main inference function: rank answers.
        
        Args:
            prompt: Input prompt
            answers: List of answers
            model_names: List of model names
        
        Returns:
            Dictionary with ranking results
        """
        logger.info(f"Ranking {len(answers)} answers")
        
        # Validate input
        try:
            input_data = PromptData(
                prompt=prompt,
                answers=answers,
                model_names=model_names
            )
        except Exception as e:
            logger.error(f"Input validation failed: {e}")
            return {"error": f"Invalid input: {str(e)}"}
        
        try:
            # Predict category
            category = self.category_predictor.predict(prompt)
            
            # Extract features
            candidates_df = self.feature_extractor.featurize_candidates(
                prompt, answers, model_names, category
            )
            
            # Align features
            X = self.feature_extractor.align_features(
                candidates_df, 
                self.ranking_model.feature_cols
            )
            
            # Get predictions and contributions
            scores, contrib_df = self.ranking_model.predict_with_contrib(X)
            
            # Create results dataframe
            results_df = candidates_df[['model_name', 'answer_text']].copy()
            results_df['predicted_score'] = scores
            results_df['category'] = category
            
            # Sort by score
            results_df = results_df.sort_values('predicted_score', ascending=False).reset_index(drop=True)
            results_df['rank'] = results_df.index + 1
            
            # Add explanations
            results_df['human_explanation'] = [
                self._build_explanation(results_df.iloc[i], contrib_df.iloc[i])
                for i in range(len(results_df))
            ]
            
            # Add keywords highlighting
            keywords = self.feature_extractor.extract_keywords(prompt)
            results_df['keywords'] = [keywords] * len(results_df)
            
            # Save results
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            csv_path = f"results_{timestamp}.csv"
            results_df.to_csv(csv_path, index=False)
            
            logger.info(f"Ranking completed. Top model: {results_df.iloc[0]['model_name']}")
            
            return {
                "results_df": results_df,
                "category": category,
                "csv_path": csv_path,
                "error": None
            }
            
        except Exception as e:
            logger.error(f"Ranking failed: {e}")
            return {"error": f"Ranking failed: {str(e)}"}
    
    def _build_explanation(self, row: pd.Series, contrib_row: pd.Series) -> str:
        """Build human-readable explanation for a prediction."""
        lines = []
        lines.append(f"Model: **{row['model_name']}**")
        lines.append(f"- Predicted score: **{row['predicted_score']:.2f}**")
        
        # Add feature values if available
        if 'prompt_answer_cosine' in row:
            lines.append(f"- Alignment (cosine): {row['prompt_answer_cosine']:.2f}")
        if 'rougeL' in row:
            lines.append(f"- Rouge-L: {row['rougeL']:.2f}")
        if 'readability' in row:
            lines.append(f"- Readability (Flesch): {int(row['readability'])}")
        if 'uniqueness' in row:
            lines.append(f"- Uniqueness: {row['uniqueness']:.2f}")
        
        # Top contributing features
        feature_cols = [c for c in contrib_row.index if c != 'bias']
        contributions = contrib_row[feature_cols].abs().sort_values(ascending=False).head(5)
        
        if len(contributions) > 0:
            feats = []
            for feat_name in contributions.index:
                value = float(contrib_row[feat_name])
                direction = "increased" if value > 0 else "decreased"
                short_name = feat_name.replace('model_name_', '').replace('category_', '')
                feats.append(f"{short_name} ({value:+.3f}) {direction}")
            
            if feats:
                lines.append("- Top contributions: " + "; ".join(feats))
        
        return "\n".join(lines)
    
    def get_redirect_url(self, model_name: str) -> str:
        """Get official URL for a model."""
        return self.llm_links.get(
            model_name,
            f"https://www.google.com/search?q={model_name}+official"
        )
