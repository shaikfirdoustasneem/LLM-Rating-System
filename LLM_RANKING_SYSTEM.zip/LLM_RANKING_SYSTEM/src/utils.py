"""
Utility functions for LLM Ranking System.
"""

import logging
import sys
from pathlib import Path
from typing import Optional
import json

try:
    import structlog
    STRUCTLOG_AVAILABLE = True
except ImportError:
    STRUCTLOG_AVAILABLE = False


def setup_logging(
    level: str = "INFO",
    log_file: Optional[Path] = None,
    use_structured: bool = False
) -> None:
    """
    Setup logging for the application.
    
    Args:
        level: Logging level (DEBUG, INFO, WARNING, ERROR)
        log_file: Optional log file path
        use_structured: Whether to use structured logging (requires structlog)
    """
    
    if use_structured and STRUCTLOG_AVAILABLE:
        structlog.configure(
            processors=[
                structlog.stdlib.filter_by_level,
                structlog.stdlib.add_logger_name,
                structlog.stdlib.add_log_level,
                structlog.stdlib.PositionalArgumentsFormatter(),
                structlog.processors.TimeStamper(fmt="iso"),
                structlog.processors.StackInfoRenderer(),
                structlog.processors.format_exc_info,
                structlog.processors.UnicodeDecoder(),
                structlog.processors.JSONRenderer()
            ],
            context_class=dict,
            logger_factory=structlog.stdlib.LoggerFactory(),
            cache_logger_on_first_use=True,
        )
    
    # Setup root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(level)
    
    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    
    if use_structured and STRUCTLOG_AVAILABLE:
        formatter = logging.Formatter('%(message)s')
    else:
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
    
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)
    
    # File handler if specified
    if log_file:
        log_file.parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(level)
        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)


def get_logger(name: str) -> logging.Logger:
    """Get logger instance."""
    return logging.getLogger(name)


def save_metrics_report(
    metrics: dict,
    output_path: Path,
    format: str = "json"
) -> None:
    """
    Save metrics report to file.
    
    Args:
        metrics: Metrics dictionary
        output_path: Output file path
        format: Format (json, txt, csv)
    """
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    if format == "json":
        with open(output_path, 'w') as f:
            json.dump(metrics, f, indent=2)
    elif format == "txt":
        with open(output_path, 'w') as f:
            for key, value in metrics.items():
                f.write(f"{key}: {value}\n")


class MetricsTracker:
    """Track training/inference metrics."""
    
    def __init__(self):
        self.metrics = {}
    
    def add(self, name: str, value: float) -> None:
        """Add metric value."""
        self.metrics[name] = value
    
    def add_dict(self, metrics_dict: dict) -> None:
        """Add multiple metrics."""
        self.metrics.update(metrics_dict)
    
    def get(self, name: str, default=None):
        """Get metric value."""
        return self.metrics.get(name, default)
    
    def to_dict(self) -> dict:
        """Get all metrics as dict."""
        return self.metrics.copy()
    
    def __repr__(self):
        return f"MetricsTracker({self.metrics})"


def highlight_text_html(text: str, keywords: list, max_length: int = 6000) -> str:
    """
    Highlight keywords in text with HTML markup.
    
    Args:
        text: Input text
        keywords: Keywords to highlight
        max_length: Maximum text length before truncation
    
    Returns:
        HTML-formatted text
    """
    import re
    
    output = str(text)
    
    for keyword in keywords:
        pattern = fr'\b({re.escape(keyword)})\b'
        output = re.sub(pattern, r'<mark>\1</mark>', output, flags=re.IGNORECASE)
    
    if len(output) > max_length:
        output = output[:max_length] + " ..."
    
    return output
