"""
Feature engineering for LLM Ranking System.
Extracts 10+ numerical features from text data.
"""

import logging
import re
import numpy as np
import pandas as pd
from collections import Counter
from typing import List, Dict, Tuple, Optional
from sklearn.metrics.pairwise import cosine_similarity
from rouge_score import rouge_scorer
import textstat
from sentence_transformers import SentenceTransformer

logger = logging.getLogger(__name__)


class FeatureExtractor:
    """Extract features from prompt/answer pairs."""
    
    def __init__(self, embedding_model: str = 'sentence-transformers/all-MiniLM-L6-v2'):
        """
        Initialize feature extractor.
        
        Args:
            embedding_model: Sentence transformer model name
        """
        logger.info(f"Loading embedding model: {embedding_model}")
        try:
            self.embedder = SentenceTransformer(embedding_model)
        except Exception as e:
            logger.warning(f"Failed to load '{embedding_model}', trying fallback")
            self.embedder = SentenceTransformer('all-MiniLM-L6-v2')
        
        self.rouge_scorer = rouge_scorer.RougeScorer(['rougeL'], use_stemmer=True)
        logger.info("Feature extractor initialized")
    
    def extract_keywords(self, text: str, max_keywords: int = 8) -> List[str]:
        """
        Extract keywords from text.
        
        Args:
            text: Input text
            max_keywords: Maximum keywords to extract
        
        Returns:
            List of keywords
        """
        words = re.findall(r"\b[a-z]{3,}\b", str(text).lower())
        
        # Common stopwords
        stop_words = {
            'the', 'and', 'for', 'you', 'with', 'that', 'this', 'from',
            'have', 'using', 'also', 'will', 'can', 'are', 'not', 'but',
            'your', 'what', 'which', 'here', 'there', 'been', 'were',
            'should', 'would', 'could', 'more', 'than', 'into', 'just'
        }
        
        words = [w for w in words if w not in stop_words]
        freq = Counter(words)
        return [w for w, _ in freq.most_common(max_keywords)]
    
    def compute_rouge_l(self, text1: str, text2: str) -> float:
        """Compute ROUGE-L similarity between two texts."""
        try:
            score = self.rouge_scorer.score(str(text1), str(text2))['rougeL'].fmeasure
            return float(score)
        except Exception as e:
            logger.debug(f"ROUGE-L computation failed: {e}")
            return 0.0
    
    def compute_readability(self, text: str) -> float:
        """Compute Flesch Reading Ease score."""
        try:
            score = float(textstat.flesch_reading_ease(str(text)))
            return score
        except Exception as e:
            logger.debug(f"Readability computation failed: {e}")
            return 50.0  # Default middle value
    
    def featurize_candidates(
        self,
        prompt: str,
        answers: List[str],
        model_names: List[str],
        category: str = "MISC"
    ) -> pd.DataFrame:
        """
        Extract features for answer candidates.
        
        Args:
            prompt: Input prompt
            answers: List of answers
            model_names: List of model names
            category: Answer category
        
        Returns:
            DataFrame with engineered features
        """
        n = len(answers)
        logger.info(f"Featurizing {n} candidates for '{category}'")
        
        # Create base dataframe
        candidates = pd.DataFrame({
            'prompt': [prompt] * n,
            'category': [category] * n,
            'answer_text': answers,
            'model_name': model_names
        })
        
        # Embeddings
        logger.debug("Computing embeddings...")
        prompt_emb = self.embedder.encode([prompt], convert_to_numpy=True)[0]
        answer_embs = self.embedder.encode(answers, convert_to_numpy=True, batch_size=32)
        
        candidates['prompt_embedding'] = [prompt_emb for _ in range(n)]
        candidates['answer_embedding'] = [emb for emb in answer_embs]
        
        # Length features
        candidates['prompt_length'] = len(str(prompt))
        candidates['answer_length'] = candidates['answer_text'].apply(lambda x: len(str(x)))
        
        # Semantic alignment
        logger.debug("Computing semantic alignment...")
        candidates['prompt_answer_cosine'] = [
            float(cosine_similarity([p], [a])[0, 0])
            for p, a in zip([prompt_emb] * n, answer_embs)
        ]
        
        # ROUGE-L
        logger.debug("Computing ROUGE-L...")
        candidates['rougeL'] = [self.compute_rouge_l(prompt, a) for a in answers]
        
        # Readability
        logger.debug("Computing readability...")
        candidates['readability'] = candidates['answer_text'].apply(self.compute_readability)
        
        # Uniqueness (vs other answers)
        logger.debug("Computing uniqueness...")
        if n > 1:
            sim_matrix = cosine_similarity(answer_embs)
            np.fill_diagonal(sim_matrix, -np.inf)
            max_similarities = np.max(sim_matrix, axis=1)
            candidates['uniqueness'] = 1.0 - np.clip(max_similarities, -1.0, 1.0)
        else:
            candidates['uniqueness'] = 1.0
        
        logger.info(f"Featurized {n} candidates successfully")
        return candidates
    
    def align_features(
        self,
        candidate_df: pd.DataFrame,
        feature_cols: List[str]
    ) -> pd.DataFrame:
        """
        Align features to match training feature set.
        
        Args:
            candidate_df: DataFrame with raw features
            feature_cols: List of expected feature column names
        
        Returns:
            DataFrame with aligned features in correct order
        """
        logger.debug(f"Aligning features to {len(feature_cols)} columns")
        
        X = pd.DataFrame(index=candidate_df.index)
        
        # Add computed features
        for f in ['prompt_answer_cosine', 'rougeL', 'readability', 'prompt_length', 'answer_length', 'uniqueness']:
            if f in candidate_df.columns:
                X[f] = candidate_df[f].astype(float)
        
        # Initialize all expected features
        for col in feature_cols:
            if col not in X.columns:
                X[col] = 0.0
        
        # One-hot encode category and model name
        for i, row in candidate_df.iterrows():
            cat_col = f"category_{row['category']}"
            model_col = f"model_name_{row['model_name']}"
            
            if cat_col in X.columns:
                X.at[i, cat_col] = 1.0
            if model_col in X.columns:
                X.at[i, model_col] = 1.0
        
        # Reorder and filter to match expected features
        X = X[feature_cols].copy()
        
        logger.debug(f"Features aligned: shape {X.shape}")
        return X


def get_feature_extractor(embedding_model: Optional[str] = None) -> FeatureExtractor:
    """Get or create feature extractor instance."""
    if embedding_model is None:
        embedding_model = 'sentence-transformers/all-MiniLM-L6-v2'
    return FeatureExtractor(embedding_model)
