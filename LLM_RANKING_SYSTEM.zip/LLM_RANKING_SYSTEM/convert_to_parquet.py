"""
Convert dataset from CSV to Parquet format.
Preserves data types and improves efficiency.
"""

import sys
import logging
from pathlib import Path
import numpy as np

project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from src.config import get_config
from src.data import DataLoader
from src.utils import setup_logging

setup_logging(level="INFO")
logger = logging.getLogger(__name__)


def convert_csv_to_parquet():
    """Convert CSV dataset to Parquet format."""
    logger.info("=" * 70)
    logger.info("CSV TO PARQUET CONVERSION")
    logger.info("=" * 70)
    
    config = get_config()
    loader = DataLoader()
    
    # Load CSV
    logger.info("\n1. Loading CSV dataset...")
    csv_path = config.get_path('paths.csv_legacy')
    df = loader.load_csv(csv_path)
    logger.info(f"Loaded {len(df)} rows")
    
    # Data type optimization
    logger.info("\n2. Optimizing data types...")
    
    # String columns (keep as-is)
    string_cols = ['prompt', 'category', 'model_name', 'answer_text']
    for col in string_cols:
        if col in df.columns:
            df[col] = df[col].astype('string')
    
    # Numeric columns
    numeric_cols = ['human_score', 'prompt_id']
    for col in numeric_cols:
        if col in df.columns and df[col].dtype == 'object':
            try:
                df[col] = pd.to_numeric(df[col])
            except:
                pass
    
    logger.info(f"Data types:\n{df.dtypes}")
    
    # Save as Parquet
    logger.info("\n3. Saving to Parquet format...")
    output_path = config.get_path('paths.features_dataset')
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    loader.save_parquet(df, output_path)
    
    # Verify
    logger.info("\n4. Verifying conversion...")
    df_verify = loader.load_parquet(output_path)
    logger.info(f"Verified: {len(df_verify)} rows loaded from Parquet")
    
    # Compare
    csv_size = csv_path.stat().st_size / 1024 / 1024  # MB
    parquet_size = output_path.stat().st_size / 1024 / 1024  # MB
    compression_ratio = (1 - parquet_size / csv_size) * 100
    
    logger.info(f"\nFile sizes:")
    logger.info(f"  CSV:     {csv_size:.2f} MB")
    logger.info(f"  Parquet: {parquet_size:.2f} MB")
    logger.info(f"  Compression: {compression_ratio:.1f}%")
    
    logger.info("\n" + "=" * 70)
    logger.info("CONVERSION COMPLETE ✅")
    logger.info("=" * 70)


if __name__ == "__main__":
    import pandas as pd
    try:
        convert_csv_to_parquet()
    except Exception as e:
        logger.error(f"Conversion failed: {e}", exc_info=True)
        sys.exit(1)
