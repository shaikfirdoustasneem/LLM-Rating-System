"""
Quick test to verify all imports and basic functionality.
Run this to validate Phase 1 setup.
"""

import sys
from pathlib import Path

project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

print("Testing imports...")

try:
    from src.config import Config, get_config
    print("✓ config module")
except ImportError as e:
    print(f"✗ config module: {e}")

try:
    from src.data import DataLoader, PromptData
    print("✓ data module")
except ImportError as e:
    print(f"✗ data module: {e}")

try:
    from src.features import FeatureExtractor
    print("✓ features module")
except ImportError as e:
    print(f"✗ features module: {e}")

try:
    from src.inference import RankingModel, RankingInference
    print("✓ inference module")
except ImportError as e:
    print(f"✗ inference module: {e}")

try:
    from src.utils import setup_logging, get_logger
    print("✓ utils module")
except ImportError as e:
    print(f"✗ utils module: {e}")

print("\nTesting configuration...")

try:
    config = get_config()
    print("✓ Config loaded")
    print(f"  Model path: {config.get('paths.model')}")
    print(f"  Embedding model: {config.get('inference.embedding_model')}")
except Exception as e:
    print(f"✗ Config test failed: {e}")

print("\nTesting Pydantic schemas...")

try:
    from src.data import PromptData
    
    # Valid input
    data = PromptData(
        prompt="What is AI?",
        answers=["AI is artificial intelligence", "AI stands for artificial intelligence"],
        model_names=["ChatGPT", "Claude"]
    )
    print("✓ PromptData validation works")
    
    # Invalid input should raise
    try:
        data = PromptData(
            prompt="",  # Empty
            answers=["Answer"],
            model_names=["Model"]
        )
        print("✗ Validation should have failed (empty prompt)")
    except:
        print("✓ Validation correctly rejects empty prompt")
    
except Exception as e:
    print(f"✗ Pydantic test failed: {e}")

print("\n" + "=" * 60)
print("✅ PHASE 1 STRUCTURE VALIDATION COMPLETE")
print("=" * 60)
print("\nNext steps:")
print("1. Run: python analyze_model.py (to extract metrics)")
print("2. Run: python convert_to_parquet.py (to migrate data)")
print("3. Create tests/ directory with test cases")
print("4. Set up logging configuration")
print("5. Create documentation in docs/")
