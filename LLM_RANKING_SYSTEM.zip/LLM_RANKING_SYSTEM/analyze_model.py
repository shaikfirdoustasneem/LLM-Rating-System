"""
Analyze model performance and generate metrics report.
Run this script to evaluate the LGBm model.
"""

import sys
import logging
import json
from pathlib import Path
from typing import Dict
import numpy as np
import pandas as pd
from sklearn.metrics import mean_squared_error, mean_absolute_error
from scipy.stats import spearmanr, kendalltau

# Setup path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from src.config import get_config
from src.data import DataLoader
from src.features import FeatureExtractor
from src.inference import RankingModel
from src.utils import setup_logging

# Setup logging
setup_logging(level="INFO")
logger = logging.getLogger(__name__)


def compute_ndcg(y_true: np.ndarray, y_score: np.ndarray, k: int = 5) -> float:
    """
    Compute Normalized Discounted Cumulative Gain.
    
    Args:
        y_true: True scores
        y_score: Predicted scores
        k: Top-K cutoff
    
    Returns:
        NDCG@k score
    """
    # Sort by predicted score
    sorted_indices = np.argsort(-y_score)[:k]
    
    # Compute DCG
    gains = y_true[sorted_indices]
    discounts = np.log2(np.arange(2, k + 2))
    dcg = np.sum(gains / discounts)
    
    # Compute IDCG (best possible DCG)
    ideal_indices = np.argsort(-y_true)[:k]
    ideal_gains = y_true[ideal_indices]
    idcg = np.sum(ideal_gains / discounts[:len(ideal_gains)])
    
    # Compute NDCG
    ndcg = dcg / idcg if idcg > 0 else 0
    return float(ndcg)


def compute_rank_accuracy(y_true: np.ndarray, y_score: np.ndarray) -> Dict:
    """
    Compute ranking accuracy metrics.
    
    Args:
        y_true: True scores
        y_score: Predicted scores
    
    Returns:
        Dictionary of ranking metrics
    """
    # Top-1 accuracy: did we get the best answer?
    true_best_idx = np.argmax(y_true)
    pred_best_idx = np.argmax(y_score)
    top1_acc = float(true_best_idx == pred_best_idx)
    
    # NDCG metrics
    ndcg1 = compute_ndcg(y_true, y_score, k=1)
    ndcg3 = compute_ndcg(y_true, y_score, k=3)
    ndcg5 = compute_ndcg(y_true, y_score, k=5)
    
    return {
        'top1_accuracy': top1_acc,
        'ndcg@1': ndcg1,
        'ndcg@3': ndcg3,
        'ndcg@5': ndcg5,
    }


def analyze_model() -> Dict:
    """Analyze model performance."""
    logger.info("=" * 70)
    logger.info("LLM RANKING SYSTEM - MODEL ANALYSIS")
    logger.info("=" * 70)
    
    config = get_config()
    loader = DataLoader()
    
    # Load dataset
    logger.info("\n1. LOADING DATA")
    logger.info("-" * 70)
    
    csv_path = config.get_path('paths.csv_legacy')
    df = loader.load_csv(csv_path)
    
    # Get statistics
    stats = loader.get_dataset_statistics(df)
    logger.info(f"Total rows: {stats['total_rows']}")
    logger.info(f"Unique prompts: {stats['unique_prompts']}")
    logger.info(f"Unique models: {stats['unique_models']}")
    logger.info(f"Unique categories: {stats['unique_categories']}")
    logger.info(f"Score range: {stats['score_min']:.2f} - {stats['score_max']:.2f}")
    logger.info(f"Score mean: {stats['score_mean']:.2f} ± {stats['score_std']:.2f}")
    
    # Category distribution
    if 'category_distribution' in stats:
        logger.info("\nCategory distribution:")
        for cat, count in stats['category_distribution'].items():
            pct = 100 * count / stats['total_rows']
            logger.info(f"  {cat}: {count} ({pct:.1f}%)")
    
    # Model distribution
    if 'model_distribution' in stats:
        logger.info("\nModel distribution:")
        for model, count in stats['model_distribution'].items():
            pct = 100 * count / stats['total_rows']
            logger.info(f"  {model}: {count} ({pct:.1f}%)")
    
    # Create train/test split
    logger.info("\n2. CREATING TRAIN/TEST SPLIT")
    logger.info("-" * 70)
    
    train_df, test_df = loader.create_train_test_split(
        df,
        test_size=0.2,
        stratify_by='category'
    )
    logger.info(f"Train set: {len(train_df)} rows")
    logger.info(f"Test set: {len(test_df)} rows")
    
    # Load model
    logger.info("\n3. LOADING MODEL")
    logger.info("-" * 70)
    
    model_path = config.get_path('paths.model')
    ranking_model = RankingModel(model_path)
    logger.info(f"Model loaded from {model_path}")
    logger.info(f"Feature columns: {len(ranking_model.feature_cols)}")
    
    # Feature extraction
    logger.info("\n4. EXTRACTING FEATURES")
    logger.info("-" * 70)
    
    feature_extractor = FeatureExtractor()
    
    # For test set, we need to extract features for each answer
    # Group by prompt_id to get candidates
    metrics_by_prompt = []
    overall_predictions = []
    overall_true = []
    
    test_prompts = test_df.groupby('prompt_id' if 'prompt_id' in test_df.columns else 'prompt')
    total_prompts = len(test_prompts)
    
    for i, (prompt_key, group) in enumerate(test_prompts):
        if i % max(1, total_prompts // 10) == 0:
            logger.info(f"Processing: {i+1}/{total_prompts} prompts")
        
        prompt = group.iloc[0]['prompt']
        answers = group['answer_text'].tolist()
        model_names = group['model_name'].tolist()
        true_scores = group['human_score'].values
        category = group.iloc[0].get('category', 'MISC')
        
        try:
            # Extract features
            candidates_df = feature_extractor.featurize_candidates(
                prompt, answers, model_names, category
            )
            
            # Align features
            X = ranking_model.align_features(candidates_df, ranking_model.feature_cols)
            
            # Predict
            predictions = ranking_model.predict(X)
            
            # Compute metrics for this prompt
            prompt_metrics = compute_rank_accuracy(true_scores, predictions)
            metrics_by_prompt.append(prompt_metrics)
            
            overall_predictions.extend(predictions)
            overall_true.extend(true_scores)
            
        except Exception as e:
            logger.warning(f"Failed to process prompt: {e}")
    
    # Convert to arrays
    overall_predictions = np.array(overall_predictions)
    overall_true = np.array(overall_true)
    
    # Compute overall metrics
    logger.info("\n5. COMPUTING METRICS")
    logger.info("-" * 70)
    
    mse = mean_squared_error(overall_true, overall_predictions)
    rmse = np.sqrt(mse)
    mae = mean_absolute_error(overall_true, overall_predictions)
    
    # Ranking metrics
    spearman_corr, spearman_pval = spearmanr(overall_true, overall_predictions)
    kendall_corr, kendall_pval = kendalltau(overall_true, overall_predictions)
    
    # Top-1 accuracy across all prompts
    top1_accs = [m['top1_accuracy'] for m in metrics_by_prompt]
    ndcg1_scores = [m['ndcg@1'] for m in metrics_by_prompt]
    ndcg3_scores = [m['ndcg@3'] for m in metrics_by_prompt]
    ndcg5_scores = [m['ndcg@5'] for m in metrics_by_prompt]
    
    metrics = {
        'dataset': {
            'total_rows': int(stats['total_rows']),
            'test_rows': len(overall_true),
            'unique_prompts': int(stats['unique_prompts']),
            'unique_models': int(stats['unique_models']),
            'unique_categories': int(stats['unique_categories']),
            'score_mean': float(stats['score_mean']),
            'score_std': float(stats['score_std']),
            'score_min': float(stats['score_min']),
            'score_max': float(stats['score_max']),
        },
        'regression_metrics': {
            'mse': float(mse),
            'rmse': float(rmse),
            'mae': float(mae),
        },
        'ranking_metrics': {
            'spearman_correlation': float(spearman_corr),
            'spearman_p_value': float(spearman_pval),
            'kendall_correlation': float(kendall_corr),
            'kendall_p_value': float(kendall_pval),
        },
        'rank_accuracy': {
            'top1_accuracy': float(np.mean(top1_accs)),
            'ndcg@1_mean': float(np.mean(ndcg1_scores)),
            'ndcg@3_mean': float(np.mean(ndcg3_scores)),
            'ndcg@5_mean': float(np.mean(ndcg5_scores)),
        },
    }
    
    # Per-category metrics
    category_metrics = {}
    if 'category' in test_df.columns:
        for category in test_df['category'].unique():
            cat_mask = (test_df['category'] == category).values
            if cat_mask.sum() > 0:
                y_true_cat = overall_true[cat_mask]
                y_pred_cat = overall_predictions[cat_mask]
                
                category_metrics[category] = {
                    'samples': int(cat_mask.sum()),
                    'rmse': float(np.sqrt(mean_squared_error(y_true_cat, y_pred_cat))),
                    'mae': float(mean_absolute_error(y_true_cat, y_pred_cat)),
                    'spearman': float(spearmanr(y_true_cat, y_pred_cat)[0]),
                }
    
    metrics['per_category'] = category_metrics
    
    # Print summary
    logger.info("\n📊 REGRESSION METRICS:")
    logger.info(f"  MSE:  {metrics['regression_metrics']['mse']:.4f}")
    logger.info(f"  RMSE: {metrics['regression_metrics']['rmse']:.4f}")
    logger.info(f"  MAE:  {metrics['regression_metrics']['mae']:.4f}")
    
    logger.info("\n📈 RANKING METRICS:")
    logger.info(f"  Spearman Correlation: {metrics['ranking_metrics']['spearman_correlation']:.4f}")
    logger.info(f"  Kendall Correlation:  {metrics['ranking_metrics']['kendall_correlation']:.4f}")
    
    logger.info("\n🏆 RANK ACCURACY:")
    logger.info(f"  Top-1 Accuracy: {metrics['rank_accuracy']['top1_accuracy']:.1%}")
    logger.info(f"  NDCG@1: {metrics['rank_accuracy']['ndcg@1_mean']:.4f}")
    logger.info(f"  NDCG@3: {metrics['rank_accuracy']['ndcg@3_mean']:.4f}")
    logger.info(f"  NDCG@5: {metrics['rank_accuracy']['ndcg@5_mean']:.4f}")
    
    if category_metrics:
        logger.info("\n📋 PER-CATEGORY PERFORMANCE:")
        for cat, cat_metrics in category_metrics.items():
            logger.info(f"\n  {cat}:")
            logger.info(f"    Samples: {cat_metrics['samples']}")
            logger.info(f"    RMSE: {cat_metrics['rmse']:.4f}")
            logger.info(f"    MAE: {cat_metrics['mae']:.4f}")
            logger.info(f"    Spearman: {cat_metrics['spearman']:.4f}")
    
    # Save report
    logger.info("\n6. SAVING REPORT")
    logger.info("-" * 70)
    
    log_dir = Path("logs")
    log_dir.mkdir(exist_ok=True)
    
    report_path = log_dir / "model_analysis_report.json"
    with open(report_path, 'w') as f:
        json.dump(metrics, f, indent=2)
    
    logger.info(f"Report saved to {report_path}")
    
    logger.info("\n" + "=" * 70)
    logger.info("ANALYSIS COMPLETE ✅")
    logger.info("=" * 70)
    
    return metrics


if __name__ == "__main__":
    try:
        metrics = analyze_model()
        print("\n✅ Analysis completed successfully!")
    except Exception as e:
        logger.error(f"Analysis failed: {e}", exc_info=True)
        sys.exit(1)
