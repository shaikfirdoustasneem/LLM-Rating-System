# Feature Engineering Guide

## Overview

The LLM Ranking System extracts **10+ numerical features** from prompt-answer pairs to predict answer quality. This document explains each feature, how it's computed, and why it matters.

## Feature Categories

### 1. Semantic Alignment Features

#### 1.1 prompt_answer_cosine

**Description**: Semantic similarity between prompt and answer embeddings

**Computation**:
```
1. Encode prompt → embedding_p (384-dim vector)
2. Encode answer → embedding_a (384-dim vector)
3. cosine_similarity = dot_product(embedding_p, embedding_a) 
                       / (norm(embedding_p) * norm(embedding_a))
```

**Range**: [0, 1]
- 0 = completely dissimilar
- 1 = semantically identical

**Importance**: Very high (directly measures relevance)

**Example**:
```
Prompt: "What is machine learning?"
Answer 1: "Machine learning is a subset of AI..." → cosine = 0.85
Answer 2: "I like pizza" → cosine = 0.02
```

**Embedding Model**: `sentence-transformers/all-MiniLM-L6-v2`
- 384-dimensional vectors
- Trained on semantic textual similarity
- Fast & accurate for short texts

---

#### 1.2 uniqueness

**Description**: How original is this answer compared to peers?

**Computation**:
```
1. Compute embeddings for all answers in batch
2. Build NxN similarity matrix (cosine between all pairs)
3. For each answer i:
   - Find max similarity to other answers (excluding self)
   - uniqueness_i = 1.0 - max_similarity_i
```

**Range**: [0, 1]
- 0 = answer is a duplicate of another
- 1 = answer is completely unique

**Importance**: Medium (prevents ranking similar answers highly)

**Example**:
```
3 answers about machine learning:
- Answer 1: "ML uses algorithms to learn from data"
- Answer 2: "ML is when algorithms learn from data" → Similar to #1
- Answer 3: "ML models are trained on labeled datasets"

Similarity matrix:
      1     2     3
1  1.0   0.92  0.65
2  0.92  1.0   0.64
3  0.65  0.64  1.0

Uniqueness:
- Answer 1: 1.0 - 0.92 = 0.08 (low, similar to #2)
- Answer 2: 1.0 - 0.92 = 0.08 (low, similar to #1)
- Answer 3: 1.0 - 0.65 = 0.35 (high, more unique)
```

---

### 2. Text Overlap & Coverage Features

#### 2.1 rougeL (ROUGE-L)

**Description**: Longest Common Subsequence (LCS) similarity

**Computation**:
```
ROUGE-L = 2 * (LCS(prompt, answer) / (len(prompt) + len(answer)))

Where LCS = Longest common subsequence (words/tokens)
```

**Range**: [0, 1]
- 0 = no overlap
- 1 = identical

**Importance**: Medium (measures keyword coverage)

**Example**:
```
Prompt: "machine learning algorithms data"
Answer: "algorithms learn from data and improve"

Common tokens: {algorithms, data, learn, from}
ROUGE-L ≈ 0.65
```

**Use Case**: Ensure answer addresses prompt keywords

**Note**: Uses stemming (e.g., "learning", "learn", "learned" → "learn")

---

### 3. Readability & Complexity Features

#### 3.1 readability (Flesch Reading Ease)

**Description**: Text difficulty level (lower = harder)

**Computation**:
```
Flesch Reading Ease = 206.835 - 1.015 * (words/sentences) 
                              - 84.6 * (syllables/words)
```

**Range**: Typically [0, 100]
- 90-100: Very easy (5th grade)
- 60-70: Standard (8th grade)
- 0-30: Very difficult (university)

**Importance**: Medium (captures clarity)

**Example**:
```
Answer 1 (Simple): "Machine learning uses computers to learn."
                    → Flesch = 85 (easy to read)

Answer 2 (Complex): "Algorithmic instantiation of parametric 
                     neural architectures facilitates optimization."
                    → Flesch = 15 (very hard to read)
```

**Use Case**: Prefer clearer, more accessible explanations

---

### 4. Length Features

#### 4.1 prompt_length

**Description**: Number of characters in the prompt

**Range**: [1, ∞)

**Importance**: Low (captures question complexity, but less important than content)

**Example**:
```
"What is AI?" → prompt_length = 12
"Explain machine learning including supervised, unsupervised learning..." 
              → prompt_length = 85
```

---

#### 4.2 answer_length

**Description**: Number of characters in the answer

**Range**: [1, ∞)

**Importance**: Low-Medium (longer ≠ better, but very short may be incomplete)

**Example**:
```
"Yes" → answer_length = 3
"Machine learning is a branch of AI that enables systems..."
       → answer_length = 500+
```

**Consideration**: Model likely prefers comprehensive but not verbose answers

---

### 5. Categorical Features (One-Hot Encoding)

#### 5.1 category_* (Category Indicators)

**Description**: Domain/category of the prompt

**Typical Categories**:
- `category_Business`: Business/Economics questions
- `category_Science`: Science/Technology questions
- `category_Health`: Health/Medical questions
- `category_MISC`: Miscellaneous (default)

**Computation**: One-hot encoding
```
If category = "Business":
  - category_Business = 1
  - category_Science = 0
  - category_Health = 0
  - category_MISC = 0
```

**Importance**: Medium (different categories may have different quality indicators)

**Example**:
```
Business question → Different quality expectations than Science question
- Business: Emphasize practical, actionable advice
- Science: Emphasize accuracy, citations, rigor
```

---

#### 5.2 model_name_* (Model Indicators)

**Description**: Which LLM generated the answer

**Typical Models**:
- `model_name_ChatGPT`
- `model_name_Claude`
- `model_name_Gemini`
- `model_name_Mistral`
- etc. (8 models total)

**Computation**: One-hot encoding
```
If model_name = "ChatGPT":
  - model_name_ChatGPT = 1
  - model_name_Claude = 0
  - model_name_Gemini = 0
  - etc.
```

**Importance**: High (models have different quality profiles)

**Example**:
```
Some models may consistently score higher due to:
- Better instruction-following
- More coherent writing
- Domain expertise (e.g., Claude on technical topics)
- Training bias

The model learns these patterns and adjusts predictions accordingly.
```

---

## Feature Interaction Example

Consider scoring two answers to "Explain machine learning":

**Answer A** (ChatGPT):
- `prompt_answer_cosine`: 0.82 (good alignment)
- `rougeL`: 0.71 (covers key concepts)
- `readability`: 72 (clear writing)
- `answer_length`: 450 (good length)
- `uniqueness`: 0.45 (somewhat original)
- `model_name_ChatGPT`: 1 (ChatGPT tends to score well)
- `category_Science`: 1
- **Predicted Score**: 8.2

**Answer B** (Unknown Model):
- `prompt_answer_cosine`: 0.79 (slightly lower)
- `rougeL`: 0.73 (good coverage)
- `readability`: 58 (harder to read)
- `answer_length`: 600 (longer)
- `uniqueness`: 0.72 (very original)
- `model_name_Other`: 1 (not a well-known model)
- `category_Science`: 1
- **Predicted Score**: 7.5

**Why A > B?**
- Better readability matters for Science
- ChatGPT has positive model bias
- Length doesn't fully compensate for harder reading level

---

## Feature Statistics

### Typical Ranges (from Training Data)

| Feature | Min | Mean | Max | Std Dev |
|---------|-----|------|-----|---------|
| prompt_answer_cosine | 0.15 | 0.72 | 0.98 | 0.18 |
| rougeL | 0.05 | 0.58 | 0.95 | 0.25 |
| readability | 10 | 65 | 92 | 18 |
| prompt_length | 15 | 85 | 500 | 110 |
| answer_length | 50 | 450 | 2500 | 380 |
| uniqueness | 0.0 | 0.55 | 1.0 | 0.35 |

### Feature Importance (from SHAP analysis)

Approximate feature importance ranking:
1. `prompt_answer_cosine` (20%)
2. `model_name_*` (18%)
3. `readability` (15%)
4. `rougeL` (14%)
5. `uniqueness` (12%)
6. `answer_length` (10%)
7. `category_*` (7%)
8. `prompt_length` (4%)

*Note: Importance may vary by model and dataset*

---

## Feature Engineering Pipeline

```
Raw Text
├─ Prompt: "What is machine learning?"
├─ Answers: ["Answer 1", "Answer 2", ...]
└─ Metadata: model_names, category

↓ [Load Embedding Model]
sentence-transformers/all-MiniLM-L6-v2

↓ [Encode Texts]
- prompt_emb ← (384,)
- answer_embs ← (N, 384)

↓ [Compute Features]
├─ Cosine similarities
├─ ROUGE-L metrics
├─ Readability scores
├─ Length statistics
├─ Uniqueness (all pairs)
└─ One-hot encodings

↓ [Feature Matrix]
Shape: (N_answers, N_features)
N_features ≈ 6 + K_categories + M_models
           ≈ 6 + 4 + 8 = 18 features

↓ [Feed to LightGBM]
→ Prediction scores (0-10)
```

---

## Computing Features Manually

### Example 1: Calculate Cosine Similarity

```python
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity

model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')

prompt = "What is machine learning?"
answer = "Machine learning is a subset of AI..."

prompt_emb = model.encode([prompt])
answer_emb = model.encode([answer])

similarity = cosine_similarity(prompt_emb, answer_emb)[0, 0]
print(f"Cosine similarity: {similarity:.3f}")  # e.g., 0.852
```

### Example 2: Calculate ROUGE-L

```python
from rouge_score import rouge_scorer

scorer = rouge_scorer.RougeScorer(['rougeL'], use_stemmer=True)
score = scorer.score(prompt, answer)['rougeL'].fmeasure
print(f"ROUGE-L: {score:.3f}")  # e.g., 0.648
```

### Example 3: Calculate Readability

```python
import textstat

readability = textstat.flesch_reading_ease(answer)
print(f"Flesch Reading Ease: {readability:.1f}")  # e.g., 72.5
```

---

## Phase 3: Advanced Features (Coming Soon)

### Planned Features

**Feature Engineering Enhancements**:
1. **Semantic Diversity**: Answer variance vs peers (not just uniqueness)
2. **Token Precision/Recall**: Key concept extraction and matching
3. **Grammar Score**: Using advanced text analysis tools
4. **Query-Answer Alignment**: Fine-tuned embedding models
5. **Model Reputation**: Historical performance per model/category
6. **Temporal Features**: Answer freshness (if timestamps available)
7. **Citation Patterns**: Authority/credibility signals
8. **Domain Expertise**: Category-specific quality indicators

**Dimensionality Reduction**:
- PCA to reduce from 18 → 10 most important features
- Feature selection with Optuna
- Ablation study to prove feature value

---

## Troubleshooting

### Problem: Very low cosine similarity (0.1)

**Causes**:
- Answer doesn't address prompt
- Different language/terminology
- Semantic mismatch

**Solution**: Check if answer is actually relevant

### Problem: Low ROUGE-L but high cosine similarity

**Causes**:
- Answer uses different words but similar concepts
- Model correctly captures semantic similarity despite different wording

**Solution**: Both metrics are complementary; this is expected

### Problem: High readability but low score

**Causes**:
- Simple explanation may lack depth
- Or simple is correct (depends on question)

**Solution**: Readability alone doesn't determine quality

### Problem: Embeddings differ slightly each run

**Causes**:
- Model has small randomness (depends on implementation)
- GPU vs CPU may produce slightly different results

**Solution**: Deterministic results require fixing random seed

---

## Performance Optimization

### Embedding Generation (Slowest)

```python
# ✓ Batch process for speed
embeddings = model.encode(texts, batch_size=32)  # ~10x faster

# ✗ Avoid processing one-by-one
embeddings = [model.encode([text])[0] for text in texts]  # Slow!
```

### ROUGE-L Computation

```python
# ✓ Vectorized if possible
from rouge_score import rouge_scorer
scorer = rouge_scorer.RougeScorer(['rougeL'], use_stemmer=True)

# ✗ Avoid recomputing for identical texts
# Solution: Cache results by hash(prompt, answer)
```

### Feature Alignment

```python
# ✓ Pre-compute alignment indices
indices = {feat: i for i, feat in enumerate(feature_cols)}

# ✗ Avoid dict lookups in loops
# Solution: Use numpy advanced indexing
```

---

## References

- **Sentence Transformers**: https://www.sbert.net/
- **ROUGE Score**: https://github.com/google-research/google-research/tree/master/rouge
- **Flesch Reading Ease**: https://en.wikipedia.org/wiki/Flesch%E2%80%93Kincaid_readability_tests
- **LightGBM**: https://lightgbm.readthedocs.io/

---

**Version**: 2.0  
**Last Updated**: May 2026  
**Status**: In Use ✅
