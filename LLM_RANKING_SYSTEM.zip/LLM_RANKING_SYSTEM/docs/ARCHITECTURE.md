# LLM Ranking System Architecture

## System Overview

```
User Input (Prompt + Answers + Models)
    ↓
[Input Validation] ← Pydantic Schemas
    ↓
[Feature Extraction] ← sentence-transformers + NLP metrics
    ↓
[Feature Alignment] ← Match training schema
    ↓
[LightGBM Prediction] ← Trained model
    ↓
[Explanation Generation] ← SHAP contributions
    ↓
[Output] → Rankings + Scores + Explanations + Redirect URLs
```

## Core Components

### 1. Configuration Management (`config.py`)

**Purpose**: Centralized, environment-aware configuration

**Key Features**:
- YAML-based settings (`config.yaml`)
- Environment variable overrides (e.g., `RANKING_MODEL_LEARNING_RATE`)
- Dynamic path resolution and creation
- Type-aware value conversion

**Usage**:
```python
from src.config import get_config

config = get_config()
model_path = config.get_path('paths.model')
lr = config.get('model.learning_rate', default=0.05)
```

### 2. Data Loading & Validation (`data.py`)

**Purpose**: Load data safely with validation

**Key Classes**:
- `DataLoader`: CSV/Parquet I/O, statistics, splitting
- `PromptData`: Pydantic schema for user input (2-10 answers, 1-5000 char prompt)
- `DatasetRow`: Schema for training data records

**Data Flow**:
```
CSV File → DataLoader.load_csv()
    ↓
Validation (nulls, score range, types)
    ↓
Parquet Export (DataLoader.save_parquet())
    ↓
Train/Test Split (stratified by category)
```

**Quality Checks**:
- Null value handling
- Score range validation (0-10)
- Type checking
- Category validation

### 3. Feature Engineering (`features.py`)

**Purpose**: Extract 10+ numerical features from text

**FeatureExtractor Class**:
- Sentence embeddings (384-dim via sentence-transformers)
- Semantic similarity (cosine)
- Text metrics (ROUGE-L, Flesch readability)
- Length statistics
- Uniqueness vs. peer answers
- Category/Model one-hot encoding

**Feature Pipeline**:
```
Text Input (Prompt + Answers)
    ↓
Embedding Generation (sentence-transformers)
    ↓
┌─────────────────────────────────────┐
│  Feature Computation:               │
│  - Cosine similarity                │
│  - ROUGE-L metric                   │
│  - Readability (Flesch)             │
│  - Answer/Prompt lengths            │
│  - Uniqueness (vs. peers)           │
└─────────────────────────────────────┘
    ↓
One-Hot Encoding (Category + Model)
    ↓
Feature Alignment to Training Schema
    ↓
Numeric Feature Matrix
```

See [FEATURES.md](FEATURES.md) for detailed feature descriptions.

### 4. Inference Pipeline (`inference.py`)

**Purpose**: Load model, predict, and explain

**Key Classes**:

#### `RankingModel`
- Loads LightGBM model from disk
- Recovers feature columns from metadata
- Makes predictions with or without feature contributions
- Handles `best_iteration` for early stopping

#### `CategoryPredictor`
- Predicts prompt domain (Business, Science, etc.)
- Falls back to "MISC" if unavailable
- Loaded from optional `.pkl` file

#### `RankingInference` (Main Pipeline)
1. Validate user input (Pydantic)
2. Predict category
3. Extract features from answers
4. Align features to model schema
5. Get predictions + contributions
6. Build human-readable explanations
7. Return rankings with metadata

**Example**:
```python
from src.inference import RankingInference

inference = RankingInference()
results = inference.predict_and_rank(
    prompt="What is machine learning?",
    answers=["ML is...", "Machine learning is..."],
    model_names=["ChatGPT", "Claude"]
)

# Results contain:
# - results_df: rankings with scores
# - category: predicted domain
# - csv_path: saved output file
```

### 5. Utilities (`utils.py`)

**Purpose**: Logging, metrics, helpers

**Key Functions**:
- `setup_logging()`: Configure structured logging
- `get_logger()`: Get logger instance
- `MetricsTracker`: Track training/inference metrics
- `highlight_text_html()`: HTML keyword highlighting

## Data Flow

### Training Flow (Offline)

```
Raw Dataset (CSV)
    ↓
Load & Validate (DataLoader)
    ↓
Train/Test Split (80/20, stratified by category)
    ↓
Feature Extraction (FeatureExtractor)
    ↓
LightGBM Training
    ├─ Input: Feature matrix + Human scores
    ├─ Output: Learned model weights
    └─ Metadata: Feature names, feature importance
    ↓
Model Serialization (joblib)
    ├─ lgbm_ranking_model.joblib (model)
    ├─ model_meta.joblib (metadata)
    └─ category_predictor.pkl (optional)
```

### Inference Flow (Online)

```
User Input
    ├─ Prompt (1-5000 chars)
    ├─ Answers (2-10, list separated by ---)
    └─ Model Names (comma-separated)
    ↓
Validation (Pydantic PromptData)
    ↓
Category Prediction
    ├─ If predictor available: predict from prompt
    └─ Else: default to "MISC"
    ↓
Feature Extraction
    ├─ Embeddings (all answers + prompt)
    ├─ Compute metrics (ROUGE, readability, etc.)
    └─ Create feature DataFrame
    ↓
Feature Alignment
    ├─ One-hot encode category + model names
    ├─ Pad missing features with 0
    └─ Match training schema exactly
    ↓
Prediction
    ├─ Model.predict(X) → Scores
    └─ Model.predict_contrib(X) → Feature contributions
    ↓
Explanation Generation
    ├─ Top contributing features
    ├─ Feature value interpretation
    └─ Human-readable text
    ↓
Output
    ├─ Rankings DataFrame
    ├─ Category label
    ├─ Saved CSV results
    └─ Redirect URLs (one per model)
```

## Model Architecture

### LightGBM Configuration

```yaml
model:
  type: lgbm
  objective: regression
  metric: mse
  learning_rate: 0.05
  num_leaves: 31
  min_samples_leaf: 20
  feature_fraction: 0.8
  bagging_fraction: 0.9
  bagging_freq: 5
  early_stopping_rounds: 50
  num_boost_round: 1000
```

### Training Details

- **Task**: Regression (predict continuous score 0-10)
- **Loss**: Mean Squared Error (MSE)
- **Regularization**: L1 (leaf-wise), bagging
- **Early Stopping**: Stop if validation MSE doesn't improve for 50 rounds
- **Feature Importance**: Gain-based (how much each feature reduces loss)

### Feature Schema

The model expects exactly N features (typically 10-20):
- 6 continuous features (cosine, rougeL, readability, lengths, uniqueness)
- K one-hot category features (e.g., category_Business, category_Science)
- M one-hot model features (e.g., model_name_ChatGPT, model_name_Claude)

If features mismatch:
1. Missing features → filled with 0
2. Extra features → ignored
3. Feature order → must match exactly

## Error Handling

### Input Validation Failures

```
User Input
    ↓
Pydantic Validation
    ├─ Empty prompt → ValueError
    ├─ Empty answers → ValueError
    ├─ Mismatched counts → ValueError
    └─ Length out of bounds → ValueError
    ↓
Return: {"error": "Invalid input: ..."}
```

### Model Loading Failures

```
Model Path Check
    ↓
Joblib Deserialization
    ├─ File not found → FileNotFoundError
    ├─ Corrupted joblib → UnpicklingError
    └─ Wrong Python version → PickleError
    ↓
Log error and raise → User sees message
```

### Feature Extraction Failures

```
Embedding Generation
    ├─ OOM (out of memory) → Log & handle gracefully
    └─ Network error → Fallback to CPU
    ↓
ROUGE/Readability Computation
    ├─ Malformed input → Return default (0, 50)
    └─ Unicode error → Handle with try-except
    ↓
Feature Alignment
    ├─ Missing feature columns → Pad with 0
    └─ Feature order mismatch → Reorder
```

## Performance Considerations

### Bottlenecks (in order)

1. **Sentence Embeddings** (~60% of inference time)
   - Mitigation: Batch processing, caching, GPU acceleration

2. **Feature Alignment** (~15% of time)
   - Mitigation: Pre-compute alignment schema, vectorize

3. **Model Prediction** (~15% of time)
   - Mitigation: Model quantization, ONNX export

4. **I/O** (~10% of time)
   - Mitigation: Connection pooling, async operations

### Optimization Strategy

**Phase 1** (Current): Establish baseline
- Single inference: ~3-5 seconds

**Phase 2** (Next):
- Embedding caching (identical prompts → reuse)
- Batch inference (process multiple at once)
- Target: <2 seconds

**Phase 3** (Future):
- Model quantization
- ONNX export for faster inference
- GPU support
- Target: <1 second

## Deployment Scenarios

### Scenario 1: Jupyter Notebook

```
User runs: Final_UI.ipynb
    ↓
Gradio server starts
    ↓
Web UI opens in browser
    ↓
User inputs → RankingInference.predict_and_rank()
    ↓
Results displayed in Gradio
```

### Scenario 2: REST API (Phase 4)

```
FastAPI Server
    ├─ POST /rank → predict_and_rank()
    ├─ GET /health → status check
    └─ POST /redirect/{model} → redirect to URL
    ↓
Async inference
    ├─ Request queuing
    ├─ Connection pooling
    └─ Response streaming
```

### Scenario 3: Docker Container

```
Docker Image
    ├─ Python 3.9+
    ├─ Dependencies (requirements.txt)
    ├─ Models (lgbm_ranking_model.joblib)
    ├─ Config (config.yaml)
    └─ Application code
    ↓
docker run -p 7860:7860 llm-ranking-system
    ↓
Gradio accessible at localhost:7860
```

## Monitoring & Observability

### Logging

All modules use Python's standard `logging` module:

```python
logger = logging.getLogger(__name__)
logger.info("Feature extraction started")
logger.warning("Category predictor not found, using default")
logger.error("Model inference failed: {e}")
```

Log output: `logs/ranking_system.log`

### Metrics

Tracked during inference:
- Embedding generation time
- Feature extraction time
- Model inference latency
- Category prediction (if available)
- Confidence scores

### Error Tracking

Exceptions logged with:
- Full stack trace
- Input context
- Fallback behavior taken

## File Formats

### Model Files

**lgbm_ranking_model.joblib**
- Format: Python pickle (joblib)
- Size: ~50-200 MB
- Contains: LightGBM model object with weights

**model_meta.joblib**
- Contains: `{'feature_cols': [list of feature names]}`
- Fallback: Feature names recovered from model or CSV

### Data Files

**converted_long_dataset_with_category_mapped.csv**
- Format: CSV (comma-separated values)
- Encoding: UTF-8
- Size: ~10-100 MB

**features_dataset.parquet**
- Format: Apache Parquet (columnar)
- Compression: Snappy (default)
- Size: ~5-30 MB (smaller than CSV)
- Preserves: Data types, embeddings

## Testing Strategy

### Unit Tests (`tests/test_features.py`)

```python
test_extract_keywords()        # Keyword extraction
test_cosine_similarity()       # Semantic similarity
test_rouge_l_metric()          # ROUGE-L computation
test_readability_score()       # Flesch score
test_feature_alignment()       # Feature schema matching
test_edge_cases()              # Empty inputs, special chars, etc.
```

### Integration Tests (`tests/test_inference.py`)

```python
test_end_to_end_ranking()      # Full pipeline
test_category_prediction()     # Category inference
test_explanation_generation()  # SHAP explanations
test_with_missing_predictor()  # Graceful degradation
test_error_handling()          # Input validation failures
```

### Performance Tests (`tests/test_performance.py`)

```python
test_inference_latency()       # Time per prediction
test_batch_processing()        # Multiple prompts
test_memory_usage()            # Peak memory
test_model_loading_time()      # Initial startup
```

## Future Enhancements

1. **Advanced Ranking**: ListNet, LambdaMART (vs. simple regression)
2. **Few-Shot Learning**: Fine-tune on user examples
3. **Uncertainty Quantification**: Quantile regression for confidence intervals
4. **Multi-Modal**: Support images/tables in prompts
5. **Streaming**: Real-time ranking updates
6. **Federation**: Multiple models per category

---

**Version**: 2.0  
**Last Updated**: May 2026  
**Status**: Production Ready ✅
